﻿using OpenCqs;

namespace InfoStore.UseCases.Queries
{
    public class GetUpcommingToDosQuery : IQuery
    {
    }
}