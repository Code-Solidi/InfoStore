﻿using OpenCqs;

namespace InfoStore.UseCases.Queries
{
    public class GetGroupsForSelectQuery : IQuery
    {
    }
}
