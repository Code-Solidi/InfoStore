﻿namespace InfoStore.Code
{
    public class ToDoNotifier
    {
        public bool HasNew { get; set; }
    }
}
