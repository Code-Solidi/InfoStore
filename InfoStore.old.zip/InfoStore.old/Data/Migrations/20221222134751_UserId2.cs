﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace InfoStore.old.Data.Migrations
{
    public partial class UserId2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserId",
                schema: "Info",
                table: "Groups",
                type: "nvarchar(450)",
                maxLength: 450,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserId",
                schema: "Info",
                table: "Groups");
        }
    }
}
