﻿namespace InfoStore.Data.Entities
{
    public class BookmarkTags
    {
        public Bookmark Bookmark { get; set; }

    }
}
