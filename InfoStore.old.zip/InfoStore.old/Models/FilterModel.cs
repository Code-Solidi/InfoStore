﻿namespace InfoStore.Models
{
}